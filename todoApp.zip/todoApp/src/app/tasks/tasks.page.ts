import { Component } from '@angular/core';

@Component({
  selector: 'app-tasks',
  templateUrl: './tasks.page.html',
  styleUrls: ['./tasks.page.scss'],
})
export class TasksPage {
  tasks: string[] = [];
  newTask: string = '';

  constructor() {}

  addTask() {
    if (this.newTask.trim().length > 0) {
      this.tasks.push(this.newTask);
      this.newTask = '';
    }
  }
}
